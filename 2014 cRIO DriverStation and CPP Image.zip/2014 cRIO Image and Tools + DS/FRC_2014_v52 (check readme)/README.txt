Drop this folder in your home directory. The imaging tool defaults
to this location so its important that everything stays as is. 
Do not unzip the image files, the tool does it automatically.